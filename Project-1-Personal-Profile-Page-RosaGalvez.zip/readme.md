This will be the project landing page for your first project with us for AOT. Note that all your other projects will have a landing page under "readme.md". Here will be all the instructions you need to complete the project. 


Project 1: Personal Profile Page.
- Follow your instructor's demo buildout of this page during class (This will begin with just HTML). Be sure to NOT copy everything they do but try to use your own creativity with the knowledge you gain. 
- Once your page is HTML complete, AOT staff will check to approve it for the next phase. 

- Once approved you can continue on to the CSS portion of this project. We are going to edit our page to make it look super nice!

- Your instuctor will once again demo out the CSS material you need to know in their own demo. Follow along just like you did with the HTML portion. (Understand but get creative!)

- Follow the Project Rubric (Linked in slides) to finalize your own project for submission. 