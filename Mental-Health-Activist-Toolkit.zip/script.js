
var factList = [
"7.4% of children aged 3-17 years (approximately 4.5 million) have a diagnosed behavior problem.",
"7.1% of children aged 3-17 years (approximately 4.4 million) have diagnosed anxiety.",
"3.2% of children aged 3-17 years (approximately 1.9 million) have diagnosed depression."
];

var fact = document.getElementById("fact");
var factBtn = document.getElementById("factBtn");
var count = 0;

if (factBtn) {
  factBtn.addEventListener("click", displayFact);
}

function displayFact() {
  fact.innerHTML = factList[count];
  count++;
  if (count == factList.length) {
    count = 0;
  }
}
