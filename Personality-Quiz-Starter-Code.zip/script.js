var CasualScore=0;
var VintageScore=0;
var ClassicScore=0;
var StreetwearScore=0;
var BohemianScore=0;
var SportyScore=0;
var GrungeScore=0;
var PunkScore=0;

var numQuestion = 0;



var q1a1= document.getElementById("q1a1");
var q1a2= document.getElementById("q1a2");
var q1a3= document.getElementById("q1a3");
var q1a4= document.getElementById("q1a4");
var q1a5= document.getElementById("q1a5");
var q1a6= document.getElementById("q1a6");
var q1a7= document.getElementById("q1a7");
var q1a8= document.getElementById("q1a8");


var q2a1= document.getElementById("q2a1");
var q2a2= document.getElementById("q2a2");
var q2a3= document.getElementById("q2a3");
var q2a4= document.getElementById("q2a4");
var q2a5= document.getElementById("q2a5");
var q2a6= document.getElementById("q2a6");
var q2a7= document.getElementById("q2a7");
var q2a8= document.getElementById("q2a8");


var q3a1= document.getElementById("q3a1");
var q3a2= document.getElementById("q3a2");
var q3a3= document.getElementById("q3a3");
var q3a4= document.getElementById("q3a4");
var q3a5= document.getElementById("q3a5");
var q3a6= document.getElementById("q3a6");
var q3a7= document.getElementById("q3a7");
var q3a8= document.getElementById("q3a8");


var q4a1= document.getElementById("q4a1");
var q4a2= document.getElementById("q4a2");
var q4a3= document.getElementById("q4a3");
var q4a4= document.getElementById("q4a4");
var q4a5= document.getElementById("q4a5");
var q4a6= document.getElementById("q4a6");
var q4a7= document.getElementById("q4a7");
var q4a8= document.getElementById("q4a8");


var q5a1= document.getElementById("q5a1");
var q5a2= document.getElementById("q5a2");
var q5a3= document.getElementById("q5a3");
var q5a4= document.getElementById("q5a4");
var q5a5= document.getElementById("q5a5");
var q5a6= document.getElementById("q5a6");
var q5a7= document.getElementById("q5a7");
var q5a8= document.getElementById("q5a8");


var q6a1= document.getElementById("q6a1");
var q6a2= document.getElementById("q6a2");
var q6a3= document.getElementById("q6a3");
var q6a4= document.getElementById("q6a4");
var q6a5= document.getElementById("q6a5");
var q6a6= document.getElementById("q6a6");
var q6a7= document.getElementById("q6a7");
var q6a8= document.getElementById("q6a8");


var result = document.getElementById("result");
var restart = document.getElementById("restart");


q1a1.addEventListener("click", Casualincrease);
q1a2.addEventListener("click", Vintageincrease);
q1a3.addEventListener("click", Sportyincrease);
q1a4.addEventListener("click", Classicincrease);
q1a5.addEventListener("click", Streetwearincrease);
q1a6.addEventListener("click", Bohemianincrease);
q1a7.addEventListener("click", Grungeincrease);
q1a8.addEventListener("click", Punkincrease);

q2a1.addEventListener("click", Vintageincrease);
q2a2.addEventListener("click", Bohemianincrease);
q2a3.addEventListener("click", Casualincrease);
q2a4.addEventListener("click", Classicincrease);
q2a5.addEventListener("click", Streetwearincrease);
q2a6.addEventListener("click", Grungeincrease);
q2a7.addEventListener("click", Punkincrease);
q2a8.addEventListener("click", Sportyincrease);

q3a1.addEventListener("click", Bohemianincrease);
q3a2.addEventListener("click", Vintageincrease);
q3a3.addEventListener("click", Streetwearincrease);
q3a4.addEventListener("click", Classicincrease);
q3a5.addEventListener("click", Grungeincrease);
q3a6.addEventListener("click", Punkincrease);
q3a7.addEventListener("click", Sportyincrease);
q3a8.addEventListener("click", Casualincrease);


q4a1.addEventListener("click", Sportyincrease);
q4a2.addEventListener("click", Streetwearincrease);
q4a3.addEventListener("click",  Casualincrease);
q4a4.addEventListener("click", Classicincrease);
q4a5.addEventListener("click", Grungeincrease);
q4a6.addEventListener("click", Bohemianincrease);
q4a7.addEventListener("click", Punkincrease);
q4a8.addEventListener("click", Vintageincrease);

q5a1.addEventListener("click",  Classicincrease);
q5a2.addEventListener("click", Casualincrease);
q5a3.addEventListener("click", Bohemianincrease);
q5a4.addEventListener("click", Streetwearincrease);
q5a5.addEventListener("click", Sportyincrease);
q5a6.addEventListener("click", Grungeincrease);
q5a7.addEventListener("click", Punkincrease);
q5a8.addEventListener("click", Vintageincrease);

q6a1.addEventListener("click", Classicincrease);
q6a2.addEventListener("click", Vintageincrease);
q6a3.addEventListener("click",  Casualincrease);
q6a4.addEventListener("click", Bohemianincrease);
q6a5.addEventListener("click", Sportyincrease);
q6a6.addEventListener("click", Grungeincrease);
q6a7.addEventListener("click", Punkincrease);
q6a8.addEventListener("click", Streetwearincrease);

restart.addEventListener("click", restartQuiz);

function Casualincrease(){
  CasualScore +=1;
  numQuestion+=1;
  console.log("numQuestion: "+numQuestion+" CasualScore: "+ CasualScore);
  if(numQuestion==6){
    console.log("The quiz is done!");
    updateResult();
  }
}

function Vintageincrease(){
  VintageScore+=1;
  numQuestion+=1;
  console.log("numQuestion: "+numQuestion+" VintageScore : "+ VintageScore);
  if(numQuestion==6){
  console.log("The quiz is done!");
  updateResult();
  } 
}

function Classicincrease(){
  ClassicScore+=1;
  numQuestion+=1;
  console.log("numQuestion: "+numQuestion+" ClassicScore: "+ ClassicScore);
  if(numQuestion==6){
  console.log("The quiz is done!");
  updateResult();
  } 
}

function Streetwearincrease(){
  StreetwearScore+=1;
  numQuestion+=1;
  console.log("numQuestion: "+numQuestion+" Streetwear: "+ StreetwearScore);
  if(numQuestion==6){
  console.log("The quiz is done!");
  updateResult();
  } 
}

function Bohemianincrease(){
  BohemianScore+=1;
  numQuestion+=1;
  console.log("numQuestion: "+numQuestion+" BohemianScore: "+ BohemianScore);
  if(numQuestion==6){
  console.log("The quiz is done!");
  updateResult();
  } 
}

function Sportyincrease(){
  SportyScore+=1;
  numQuestion+=1;
  console.log("numQuestion: "+numQuestion+" SportyScore: "+ SportyScore);
  if(numQuestion==6){
  console.log("The quiz is done!");
  updateResult();
  } 
}

function Grungeincrease(){
  GrungeScore+=1;
  numQuestion+=1;
  console.log("numQuestion: "+numQuestion+" GrungeScore: "+ GrungeScore);
  if(numQuestion==6){
  console.log("The quiz is done!");
  updateResult();
  } 
}

function Punkincrease(){
  PunkScore+=1;
  numQuestion+=1;
  console.log("numQuestion: "+numQuestion+" PunkScore: "+ PunkScore);
  if(numQuestion==6){
  console.log("The quiz is done!");
  updateResult();
  } 
}




function restartQuiz(){
  result.innerHTML= "Your result is..";
  CasualScore=0;
  VintageScore=0;
  ClassicScore=0;
  StreetwearScore=0;
  BohemianScore=0;
  SportyScore =0;
  GrungeScore=0;
  PunkScore=0;
  numQuestion=0;
  console.log(CasualScore);
  console.log(VintageScore);
   console.log(ClassicScore);
  console.log(StreetwearScore);
   console.log(BohemianScore);
  console.log(SportyScore);
  console.log(GrungeScore);
  console.log(PunkScore);
  console.log(numQuestion);
}

function updateResult(){
  if(CasualScore>=2){
  result.innerHTML="Your style is casual";
  console.log("You have a Casual Style!");
  }
  else if(VintageScore>=2){
  result.innerHTML="Your style is Vintage";
  console.log("You have Vintage style");
  }
  else if(ClassicScore>=2){
  result.innerHTML="Your style is Classic";
  console.log("You have Classic style");
  }
  else if(StreetwearScore>=2){
  result.innerHTML="Your style is Streetwear";
  console.log("Your style is Streetwear");
  }
  else if(BohemianScore>=2){
  result.innerHTML="Your style is bohemian";
  console.log("You have Bohemian style");
  }
  else if(SportyScore>=2){
  result.innerHTML="Your style is sporty";
  console.log("You have sporty style");
  }
  else if (GrungeScore >=2){
  result.innerHTML="Your style is grunge";
  console.log("You have grunge style");
  }
  else if (PunkScore >=2)
result.innerHTML="Your style is punk";
console.log("You have a punk style")
}